<h2><?= e(trans('backend::lang.account.password_restore')) ?></h2>

<?= Form::open() ?>
    <input type="hidden" name="postback" value="1" />

    <p><?= e(trans('backend::lang.account.enter_login')) ?></p>

    <div class="form-elements" role="form">

        <!-- Username -->
        <div class="form-group">
            <label class="form-label" for="login-input">
                <?= e(trans('backend::lang.account.input_username')) ?>
            </label>

            <input
                type="text"
                name="login"
                id="login-input"
                value="<?= e(post('login')) ?>"
                class="form-control"
                placeholder=""
                autocomplete="off"
                maxlength="255" />
        </div>

        <button type="submit" class="btn btn-primary restore-button">
            <?= e(trans('backend::lang.account.restore')) ?>
        </button>

        <p class="pull-right forgot-password">
            <a href="<?= Backend::url('backend/auth') ?>" class="text-muted">
                <?= e(trans('backend::lang.form.cancel')) ?>
            </a>
        </p>
    </div>
<?= Form::close() ?>

<?= $this->fireViewEvent('backend.auth.extendRestoreView') ?>
