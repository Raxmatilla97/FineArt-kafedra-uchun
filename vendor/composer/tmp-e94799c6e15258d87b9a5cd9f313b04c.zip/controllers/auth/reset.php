<h2><?= e(trans('backend::lang.account.password_reset')) ?></h2>

<?= Form::open() ?>
    <input type="hidden" name="postback" value="1" />
    <input type="hidden" name="id" value="<?= e($id) ?>" />
    <input type="hidden" name="code" value="<?= e($code) ?>" />

    <p><?= e(trans('backend::lang.account.enter_new_password')) ?></p>

    <div class="form-elements" role="form">

        <!-- Password -->
        <div class="form-group">
            <label class="form-label" for="password-input">
                <?= e(trans('backend::lang.account.input_password')) ?>
            </label>

            <input
                type="password"
                name="password"
                id="password-input"
                value=""
                class="form-control password"
                autocomplete="off"
                maxlength="255" />
        </div>

        <!-- Submit Login -->
        <button type="submit" class="btn btn-primary">
            <?= e(trans('backend::lang.account.reset')) ?>
        </button>

        <p class="pull-right forgot-password">
            <a href="<?= Backend::url('backend/auth') ?>" class="text-muted">
                <?= e(trans('backend::lang.form.cancel')) ?>
            </a>
        </p>
    </div>
<?= Form::close() ?>
