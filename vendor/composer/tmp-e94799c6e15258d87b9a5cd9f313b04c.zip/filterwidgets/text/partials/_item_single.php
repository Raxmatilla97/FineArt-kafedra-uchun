<div class="facet-item is-grow">
    <input
        name="Filter[value]"
        value="<?= e($scope->value ?: $scope->default) ?>"
        class="form-control form-control-sm popup-allow-focus"
        autocomplete="off"
        placeholder="" />
</div>
