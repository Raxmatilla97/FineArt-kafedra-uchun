<div class="facet-item">
    <input
        name="Filter[value]"
        type="number"
        value="<?= e($scope->value ?: $scope->default) ?>"
        class="form-control form-control-sm popup-allow-focus w-90"
        autocomplete="off"
        placeholder="0" />
</div>
