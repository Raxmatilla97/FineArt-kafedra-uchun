// Importing JavaScript
//

module.exports = [
    "js/backend.js",
    "js/checkbox.js",
    "js/bs3-adapter.js",
    "js/list.sortable.js",
];
