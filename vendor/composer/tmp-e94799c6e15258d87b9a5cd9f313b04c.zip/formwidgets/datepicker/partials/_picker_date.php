<!-- Date -->
<div class="input-with-icon right-align">
    <i class="icon icon-calendar-o"></i>
    <input
        type="text"
        id="<?= $this->getId('date') ?>"
        class="form-control align-right"
        autocomplete="off"
        <?= $field->getAttributes() ?>
        data-datepicker />
</div>
