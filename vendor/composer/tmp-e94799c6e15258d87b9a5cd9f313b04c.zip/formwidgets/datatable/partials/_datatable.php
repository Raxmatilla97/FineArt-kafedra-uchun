<div
    id="<?= $this->getId() ?>"
    class="field-datatable size-<?= $size ?>">

    <?= $table->render() ?>
</div>
