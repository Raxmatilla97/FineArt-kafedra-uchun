<div class="nested-form <?= $this->showPanel ? 'is-paneled' : '' ?>">
    <?= $this->formWidget->render() ?>
</div>
