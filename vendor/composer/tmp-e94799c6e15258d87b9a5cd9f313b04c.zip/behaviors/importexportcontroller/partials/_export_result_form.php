<?php if (!$this->fatalError): ?>

    <div class="modal-body">
        <p>
            <?= e(trans('backend::lang.import_export.processing_successful_line1')) ?>
            <?= e(trans('backend::lang.import_export.processing_successful_line2')) ?>
        </p>
    </div>
    <div class="modal-footer">
        <a
            href="<?= $returnUrl ?>"
            class="btn btn-success"
            data-dismiss="popup">
            <?= e(trans('backend::lang.form.complete')) ?>
        </a>
    </div>

    <script> window.location = '<?= $fileUrl ?>'; </script>

<?php else: ?>

    <div class="modal-body">
        <p class="flash-message static error"><?= e($this->fatalError) ?></p>
    </div>
    <div class="modal-footer">
        <button
            type="button"
            class="btn btn-default"
            data-dismiss="popup">
            <?= e(trans('backend::lang.form.close')) ?>
        </button>
    </div>

<?php endif ?>
