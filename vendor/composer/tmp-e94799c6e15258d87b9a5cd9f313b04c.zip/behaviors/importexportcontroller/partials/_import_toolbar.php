<div data-control="toolbar">
    <a
        href="javascript:;"
        id="showIgnoredColumnsButton"
        class="btn btn-sm btn-secondary oc-icon-eye disabled"
        onclick="$.oc.importBehavior.showIgnoredColumns()">
        <?= e(trans('backend::lang.import_export.show_ignored_columns')) ?>
    </a>
    <a
        href="javascript:;"
        id="autoMatchColumnsButton"
        class="btn btn-sm btn-secondary oc-icon-bullseye"
        onclick="$.oc.importBehavior.autoMatchColumns()">
        <?= e(trans('backend::lang.import_export.auto_match_columns')) ?>
    </a>
</div>
