<?php if ($relationViewMode == 'single'): ?>
    <button
        class="btn btn-sm btn-secondary"
        data-request="onRelationButtonUnlink"
        data-request-success="$.oc.relationBehavior.changed('<?= e($this->vars['relationField']) ?>', 'removed')"
        data-request-confirm="<?= e($this->relationGetMessage('confirmUnlink')) ?>"
        data-stripe-load-indicator
    >
        <i class="octo-icon-unlink"></i> <?= e($this->relationGetMessage('buttonUnlink')) ?>
    </button>
<?php else: ?>
    <button
        class="btn btn-sm btn-secondary"
        onclick="$(this).data('request-data', {
            checked: $('#<?= $this->relationGetId('view') ?> .control-list').listWidget('getChecked')
        })"
        disabled="disabled"
        data-request="onRelationButtonUnlink"
        data-request-success="$.oc.relationBehavior.changed('<?= e($this->vars['relationField']) ?>', 'removed')"
        data-request-confirm="<?= e($this->relationGetMessage('confirmUnlink')) ?>"
        data-trigger-action="enable"
        data-trigger="#<?= $this->relationGetId('view') ?> .control-list tbody input[type=checkbox]"
        data-trigger-condition="checked"
        data-stripe-load-indicator
    >
        <i class="octo-icon-unlink"></i> <?= e($this->relationGetMessage('buttonUnlink')) ?>
    </button>
<?php endif ?>
