<a
    data-control="popup"
    data-size="huge"
    data-handler="onRelationButtonLink"
    href="javascript:;"
    class="btn btn-sm btn-secondary"
>
    <i class="octo-icon-link"></i> <?= e($this->relationGetMessage('buttonLink')) ?>
</a>
