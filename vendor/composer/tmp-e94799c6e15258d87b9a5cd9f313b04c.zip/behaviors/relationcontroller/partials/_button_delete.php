<?php if ($relationViewMode == 'single'): ?>
    <button
        class="btn btn-sm btn-secondary oc-icon-trash-o"
        data-request="onRelationButtonDelete"
        data-request-confirm="<?= e($this->relationGetMessage('confirmDelete')) ?>"
        data-request-success="$.oc.relationBehavior.changed('<?= e($this->vars['relationField']) ?>', 'deleted')"
        data-stripe-load-indicator
    >
        <?= e($this->relationGetMessage('buttonDelete')) ?>
    </button>
<?php else: ?>
    <button
        class="btn btn-sm btn-secondary"
        onclick="$(this).data('request-data', {
            checked: $('#<?= $this->relationGetId('view') ?> .control-list').listWidget('getChecked')
        })"
        disabled="disabled"
        data-request="onRelationButtonDelete"
        data-request-confirm="<?= e($this->relationGetMessage('confirmDelete')) ?>"
        data-request-success="$.oc.relationBehavior.changed('<?= e($this->vars['relationField']) ?>', 'deleted')"
        data-trigger-action="enable"
        data-trigger="#<?= $this->relationGetId('view') ?> .control-list tbody input[type=checkbox]"
        data-trigger-condition="checked"
        data-stripe-load-indicator
    >
        <i class="octo-icon-delete"></i> <?= e($this->relationGetMessage('buttonDelete')) ?>
    </button>
<?php endif ?>
