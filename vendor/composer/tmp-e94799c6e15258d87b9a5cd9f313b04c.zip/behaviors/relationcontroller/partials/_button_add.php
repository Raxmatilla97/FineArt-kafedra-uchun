<a
    data-control="popup"
    data-size="huge"
    data-handler="onRelationButtonAdd"
    href="javascript:;"
    class="btn btn-sm btn-secondary"
>
    <i class="octo-icon-list-add"></i> <?= e($this->relationGetMessage('buttonAdd')) ?>
</a>
