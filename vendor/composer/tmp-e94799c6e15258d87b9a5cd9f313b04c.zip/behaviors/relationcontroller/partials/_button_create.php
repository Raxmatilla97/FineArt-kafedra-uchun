<a
    data-control="popup"
    data-size="huge"
    data-handler="onRelationButtonCreate"
    href="javascript:;"
    class="btn btn-sm btn-secondary"
>
    <i class="octo-icon-create"></i> <?= e($this->relationGetMessage('buttonCreate')) ?>
</a>
